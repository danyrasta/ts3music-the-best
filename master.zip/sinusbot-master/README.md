# sinusbot

Docker container for the TeamSpeak 3 SinusBot by Michael Friese.

TeamSpeak 3 SinusBot Homepage: https://frie.se/ts3bot/
